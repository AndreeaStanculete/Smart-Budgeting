
// nevermind
function CloseReceiptsDataModal() {
    $.ajax({
        type: "POST",
        url: "~/mainPage.py",
        data: { modalId: 444}
      }).done(function() {
         // do something
      });

  }

   
function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if ( (charCode > 31 && charCode < 48) || charCode > 57) {
            return false;
        }
        return true;
    }
