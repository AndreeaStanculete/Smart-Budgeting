from django.shortcuts import render
from django.views.decorators.http import require_http_methods

from budgetingApp.decorators.security import require_authentication

from budgetingApp.models import UserSettings, Income, Expense, PeriodicalExpense, PeriodicalIncome

from datetime import date, datetime
from dateutil.relativedelta import relativedelta

from budgetingApp.utils.crawler import searchForPrices

@require_authentication()
# @require_http_methods(['HEAD', 'GET', 'POST'])
def Profile(request):

    searchResults = []
    if request.method == 'POST':
        if request.POST['modalId'] == '100':
            searchResult = searchForPrices(request.POST["searchInput"])
            print(searchResult)

            contor = 1
            for obj in searchResult:
                searchResults.append([contor, obj["Name"], obj["Price"], obj["URL"]])
                contor = contor + 1
    
    img = ""
    curr = ""
    for obj in UserSettings.getObjectsByUser(request.user):
        img = obj.Picture
        curr = obj.Currency

    PeriodicalIncomes = {}
    foundIncome = 0
    for obj in PeriodicalIncome.getObjectsByUser(request.user):
        if obj.Periodical not in PeriodicalIncomes.keys():
            PeriodicalIncomes[obj.Periodical] = []
            PeriodicalIncomes[obj.Periodical].append([obj.Type, obj.Amount, obj.Currency, obj.Date, obj.Periodical])
            foundIncome = 1
        else:
            PeriodicalIncomes[obj.Periodical].append([obj.Type, obj.Amount, obj.Currency, obj.Date, obj.Periodical])

    PeriodicalExpenses = {}
    foundExpenses = 0
    for obj in PeriodicalExpense.getObjectsByUser(request.user):
        if obj.Periodical not in PeriodicalExpenses.keys():
            PeriodicalExpenses[obj.Periodical] = []
            PeriodicalExpenses[obj.Periodical].append([obj.Type, obj.Amount, obj.Currency, obj.Date, obj.Periodical])
            foundExpenses = 1
        else:
            PeriodicalExpenses[obj.Periodical].append([obj.Type, obj.Amount, obj.Currency, obj.Date, obj.Periodical])

    context={
        "username": request.user.username,
        "email": request.user.email,
        "imageURL": img,
        "currency": curr,
        "verified": 0,
        "foundIncome": foundIncome,
        "PeriodicalIncomes": PeriodicalIncomes,
        "foundExpenses": foundExpenses,
        "PeriodicalExpenses": PeriodicalExpenses,
        "SearchResult": searchResults
    }

    return render(request, 'Profile.html', context=context)