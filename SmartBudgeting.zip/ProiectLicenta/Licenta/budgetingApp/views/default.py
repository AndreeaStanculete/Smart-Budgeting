from django.shortcuts import render
from django.views.decorators.http import require_safe

from budgetingApp.decorators.security import require_authentication
# def index(request, id: str):
#     if request.method == "GET":
#         return render(request, 'index.html', {'id': id})

@require_authentication(required=False, redirect_url='main')
@require_safe
def Index(request):
    return render(request, 'index.html')

@require_safe
def DisplayError(request, errorCode: int):
    return render(request, 'errorPage.html', context={'errorCode': errorCode})