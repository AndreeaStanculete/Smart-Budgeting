from django.shortcuts import redirect
from django.views.decorators.http import require_http_methods
from django.contrib.auth import logout

from budgetingApp.decorators.security import require_authentication

from django.contrib.auth.models import User
from budgetingApp.models import Income, Expense, UserSettings, PeriodicalIncome, PeriodicalExpense

from budgetingApp.utils.crawler import searchForPrices

@require_authentication()
@require_http_methods(['GET', 'POST'])
def PerformOperation(request, operationId: str):
    if request.method == 'POST':
        if operationId == 'add_income':
            Income.createNewObject(
                request.user,
                request.POST["type"],
                request.POST["amount"],
                request.POST["currency"],
                request.POST["period"])
            
            if request.POST["period"] != "None":
                PeriodicalIncome.createNewObject(
                    request.user,
                    request.POST["type"],
                    request.POST["amount"],
                    request.POST["currency"],
                    request.POST["period"])
            
        if operationId == 'add_expense_form':
            Expense.createNewObject(
                request.user,
                request.POST["typeExp"],
                request.POST["amountExp"],
                request.POST["currencyExp"],
                request.POST["periodExp"])
            
            if request.POST["periodExp"] != "None":
                PeriodicalExpense.createNewObject(
                    request.user,
                    request.POST["typeExp"],
                    request.POST["amountExp"],
                    request.POST["currencyExp"],
                    request.POST["periodExp"])
            
        if operationId == 'add_expense':
            items = (len(request.POST.keys()) - 2) // 2

            for i in range(1,items+1):
                Expense.createNewObject(
                    request.user,
                    request.POST['T' + str(i)],
                    request.POST['A' + str(i)],
                    request.POST["currencyExp"],
                    "None")
                
            # to be completed !
            
    if operationId == 'logout':
        logout(request)
        return redirect('/')
    return redirect('Main')