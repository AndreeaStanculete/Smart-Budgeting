from django.shortcuts import redirect
from django.views.decorators.http import require_http_methods

from budgetingApp.decorators.security import require_authentication

from django.contrib.auth.models import User
from budgetingApp.models import UserSettings

@require_authentication()
@require_http_methods(['GET', 'POST'])
def PerformProfileOperation(request, operationId: str):
    if request.method == 'POST':
        if operationId == 'change_pic':
            picNumber = int(request.POST['num']) 
            picURLs = [
                '/static/pictures/male_avatar.svg',
                '/static/pictures/female_avatar.svg',
                '/static/pictures/male_avatar2.svg',
                '/static/pictures/female_avatar2.svg'
            ]
            
            settings = UserSettings.getObjectsByUser(request.user)[0]
            settings.updateProfilePicture(picURLs[picNumber])

        if operationId == 'change_email':
            currentUser = User.objects.get(username=request.user.username)
            currentUser.email = request.POST['newEmail']
            currentUser.save()

        if operationId == 'change_username':
            loggedinUser = User.objects.get(username=request.user.username)
            context = {"verified": 1, "error": "Username already exists."}
            try:
                user = User.objects.get(username=request.POST["newUsername"])
                
            except User.DoesNotExist:
                loggedinUser.username = request.POST['newUsername']
                loggedinUser.save()

        # if operationId == 'change_password':
            # something
        
        if operationId == 'change_settings':
            currency = request.POST['currency'] 
            settings = UserSettings.getObjectsByUser(request.user)[0]
            settings.updateCurrency(currency)
            settings.save()

    return redirect('Profile')
            