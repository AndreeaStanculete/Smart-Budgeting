from .authentication import Login, Register
from .mainPage import Main
from .default import Index, DisplayError
from .operations import PerformOperation
from .profile import Profile
from .operationsProfile import PerformProfileOperation
from .pieChart import pie_chart