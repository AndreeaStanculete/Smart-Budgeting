from django.shortcuts import render
from datetime import date

from budgetingApp.models import Income, Expense, UserSettings

def pie_chart(request):
    labels = []
    data = []

    MainCurrency = UserSettings.getObjectsByUser(request.user)[0]
    today = date.today()

    typeExpense = {}
    for obj in Expense.getObjectsByUser(request.user):
        if today.month == obj.Date.month:
            if obj.Currency == MainCurrency:
                if obj.type not in typeExpense.keys():
                    typeExpense[obj.Currency] = obj.Amount
                else:
                    typeExpense[obj.Currency] += obj.Amount


    for key, value in typeExpense:
        labels.append(key)
        data.append(value)

    return render(request, 'Main.html', {
        'labels': labels,
        'data': data,
    })