from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.views.decorators.http import require_http_methods

from budgetingApp.decorators.security import require_authentication

from budgetingApp.models import UserSettings
from budgetingApp.utils.databaseUpdate import updateUserData

# def index(request, id: str):
#     if request.method == "GET":
#         return render(request, 'index.html', {'id': id})

@require_authentication(required=False, redirect_url='main')
@require_http_methods(['HEAD', 'GET', 'POST'])
def Login(request):
    context = {}
    
    if request.method == 'POST':
        context = {"error": "Invalid login"}

        username = request.POST["username"]
        password = request.POST["password"]

        user = authenticate(request, username=username, password=password)
        if user is not None:
            # A backend authenticated the credentials
            login(request, user)
            updateUserData(user)
            return redirect('Main')

    return render(request, 'Login.html', context=context)

@require_authentication(required=False, redirect_url='main')
@require_http_methods(['HEAD', 'GET', 'POST'])
def Register(request):
    context = {}
    if request.method == "POST":
        context = {"error": "Username already exists."}
        try:
            user = User.objects.get(username=request.POST["username"])
        except User.DoesNotExist:
            user = User.objects.create_user(request.POST["username"], request.POST["email"], request.POST["password"])
            user.save()
            UserSettings.createNewObject(user)
            login(request, user)
            return redirect('Main')
    return render(request, 'Register.html', context=context)

