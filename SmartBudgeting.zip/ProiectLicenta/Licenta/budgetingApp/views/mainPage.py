import json
from django.shortcuts import render
from django.views.decorators.http import require_http_methods
from django.core.files.storage import FileSystemStorage

from datetime import date

from budgetingApp.decorators.security import require_authentication

from budgetingApp.models import Income
from budgetingApp.models import Expense
from budgetingApp.models import UserSettings

from budgetingApp.utils.receipt import saveReceiptToFile, parseReceiptImage
from budgetingApp.utils.crawler import searchForPrices

@require_authentication()
@require_http_methods(['HEAD', 'GET', 'POST'])
def Main(request):
    newExpenses = []
    searchResults = []
    if request.method == 'POST':
        if request.POST['modalId'] == '100':
            searchResult = searchForPrices(request.POST["searchInput"])
            print(searchResult)

            contor = 1
            for obj in searchResult:
                searchResults.append([contor, obj["Name"], obj["Price"], obj["URL"]])
                contor = contor + 1

        if request.POST["modalId"] == "1":
            
            #Files from upload

            fs = FileSystemStorage()
            for filename, _ in request.FILES.items():
                uploadedFile = request.FILES[filename]
                
                fs.save("tmp/receipt.jpeg", uploadedFile)
                
                content = parseReceiptImage()
                # print(content['receipts'][0]['total'])
                contor = 1

                with open('tmp/json.json', 'w', encoding="utf-8") as file:
                    file.write(json.dumps(content))

                f = open('tmp/json.json', 'r', encoding="utf-8")
                data = json.load(f)
                for obj in data["receipts"]:
                    newExpenses.append([contor, obj["total"], "Lei"])
                    contor = contor + 1
                f.close()

        elif request.POST["modalId"] == "2":
            #File from camera
            saveReceiptToFile(request.POST.get('photoFile'))

            content = parseReceiptImage()
            print(content)

    today = date.today()
    
    incomeList = []
    sumIncome = {}
    remaining = {}
    for obj in Income.getObjectsByUser(request.user):
        if today.month == obj.Date.month:
            incomeList.append([obj.Type, obj.Amount, obj.Currency])

            if obj.Currency not in sumIncome.keys():
                sumIncome[obj.Currency] = obj.Amount
                remaining[obj.Currency] = obj.Amount
            else:
                sumIncome[obj.Currency] += obj.Amount
                remaining[obj.Currency] += obj.Amount

    MainCurrency = UserSettings.getObjectsByUser(request.user)[0]

    expenseList = []
    sumExpense = {}
    typeExpense = {}
    for obj in Expense.getObjectsByUser(request.user):
        if today.month == obj.Date.month:
            expenseList.append([obj.Type, obj.Amount, obj.Currency])

            if obj.Currency == MainCurrency:
                if obj.type not in typeExpense.keys():
                    typeExpense[obj.Currency] = obj.Amount
                else:
                    typeExpense[obj.Currency] += obj.Amount

            if obj.Currency not in sumExpense.keys():
                sumExpense[obj.Currency] = obj.Amount
                if obj.Currency not in remaining.keys():
                    remaining[obj.Currency] = -obj.Amount
                else:
                    remaining[obj.Currency] -= obj.Amount
            else:
                sumExpense[obj.Currency] += obj.Amount
                remaining[obj.Currency] -= obj.Amount

    context={'Incomes': incomeList, 'TotalIncome': sumIncome, 'Expenses': expenseList, 'TotalExpense': sumExpense, 'NewExpenses': newExpenses, 
             'MainCurrency': MainCurrency.Currency, 'typesOfExpenses': typeExpense, 'remainingMoney': remaining, 'SearchResult': searchResults}

    return render(request, 'Main.html', context=context)