from requests import get
from bs4 import BeautifulSoup

def searchForPrices(product: str) -> str:
    alteredProduct = product.replace(' ', '+')
    
    searchURLs = [
        f"https://www.emag.ro/search/{product}?ref=effective_search",
        # f"https://www.compari.ro/CategorySearch.php?st={alteredProduct}"
    ]

    searchKeyWords = [
        'product-new-price',
        'price'
    ]

    priceListWithURL = []
    searchURL = f"https://www.emag.ro/search/{product}?ref=effective_search"
    searchClass = 'product-new-price'

    page = get(searchURL)
    soup = BeautifulSoup(page.content, 'html.parser')

    for item in soup.find_all(class_=searchClass):
        priceListWithURL.append({
            'Price': float(item.getText()[:-4].replace('.', '').replace(',', '.')),
            'Name': "",
            'URL': ""
        })
    for index, item in enumerate(soup.find_all('a', class_="card-v2-title")):
        priceListWithURL[index]['URL'] = item['href']
        priceListWithURL[index]['Name'] = item.text
    priceListWithURL.sort(key = lambda x: x['Price'])

    return priceListWithURL[:2]

if __name__ == '__main__':
    print(searchForPrices("Samsung Galaxy A34"))