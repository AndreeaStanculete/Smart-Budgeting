
from budgetingApp.models import UserSettings, Income, Expense, PeriodicalExpense, PeriodicalIncome

from datetime import date, datetime
from dateutil.relativedelta import relativedelta


def updateUserData(user): 
    today = date.today()

    for obj in PeriodicalIncome.getObjectsByUser(user):
        while obj.Date <= today:
            Income.createNewObjectD(
                user,
                obj.Type,
                obj.Amount,
                obj.Currency,
                obj.Periodical,
                obj.Date)
            
            if obj.Periodical == 'Monthly':
                obj.Date = obj.Date + relativedelta(months=+1)
            elif obj.Periodical == 'Bi-weekly':
                obj.Date = obj.Date + relativedelta(days=+14)
            elif obj.Periodical == 'Weekly':
                obj.Date = obj.Date + relativedelta(days=+7)
            elif obj.Periodical == 'Yearly':
                obj.Date = obj.Date + relativedelta(months=+12)

        obj.UpdateDate(obj.Date)

    for obj in PeriodicalExpense.getObjectsByUser(user):
        while obj.Date <= today:
            Income.createNewObjectD(
                user,
                obj.Type,
                obj.Amount,
                obj.Currency,
                obj.Periodical,
                obj.Date)
            
            if obj.Periodical == 'Monthly':
                obj.Date = obj.Date + relativedelta(months=+1)
            elif obj.Periodical == 'Bi-weekly':
                obj.Date = obj.Date + relativedelta(days=+14)
            elif obj.Periodical == 'Weekly':
                obj.Date = obj.Date + relativedelta(days=+7)
            elif obj.Periodical == 'Yearly':
                obj.Date = obj.Date + relativedelta(months=+12)

        obj.UpdateDate(obj.Date)
