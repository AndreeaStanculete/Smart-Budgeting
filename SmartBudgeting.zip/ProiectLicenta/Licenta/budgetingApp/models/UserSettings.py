from django.db import models
from django.contrib.auth.models import User
from datetime import date

class UserSettings(models.Model):
    User = models.ForeignKey(User, on_delete=models.CASCADE)
    Picture = models.CharField(max_length=100)
    Currency = models.CharField(max_length=50)


    @staticmethod
    def getObjectsByUser(user: User) -> list:
        """
        Returns all objects belonging to a specific user.

        Args:
            - user (User): The user to lookup
        """
        return UserSettings.objects.filter(User = user)

    @staticmethod
    def createNewObject(user: User):
        """
        Creates a new Settings object and saves it to database.

        Args:
            - user (User): The current user
        """
        obj = UserSettings(
            User = user, 
            Currency = 'EUR',
            Picture = "/static/pictures/male_avatar.svg"
        )
        obj.save()

    def updateProfilePicture(self, pictureURL: str):
        """
        Updates the profile picture of a user.

        Args:
            - user (User): The current user
            - pictureURL (str): The URL of the new picture
        """
        self.Picture = pictureURL
        self.save()

    def updateCurrency(self, currency: str):
        """
        Updates the main currency of a user.

        Args:
            - user (User): The current user
            - currency (str): The new currency
        """
        self.Currency = currency
        self.save()