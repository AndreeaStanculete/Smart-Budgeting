from django.db import models
from django.contrib.auth.models import User

from datetime import date, datetime
from dateutil.relativedelta import relativedelta

class PeriodicalExpense(models.Model):
    User = models.ForeignKey(User, on_delete=models.CASCADE)
    Type = models.CharField(max_length=50)
    Amount = models.IntegerField()
    Currency = models.CharField(max_length=50)
    Date = models.DateField()
    Periodical = models.CharField(max_length=50)


    @staticmethod
    def getObjectsByUser(user: User) -> list:
        """
        Returns all PeriodicalExpense objects belonging to a specific user.

        Args:
            - user (User): The user to lookup
        """
        return PeriodicalExpense.objects.filter(User = user)

    @staticmethod
    def createNewObject(user: User, type: str, amount: int, currency: str, periodical: str):
        """
        Creates a new PeriodicalExpense object and saves it to database.

        Args:
            - user (User): The current user
            - type (str): The type of income (e.g. Salary)
            - amount (int): The amount of currency gained
        """
        today = date.today()
        if periodical == 'Monthly':
            today = today + relativedelta(months=+1)
        elif periodical == 'Bi-weekly':
            today = today + relativedelta(days=+14)
        elif periodical == 'Weekly':
            today = today + relativedelta(days=+7)
        elif periodical == 'Yearly':
            today = today + relativedelta(months=+12)

        obj = PeriodicalExpense(
            User = user, 
            Type = type, 
            Amount = amount, 
            Currency = currency,
            Date = today,
            Periodical = periodical)
        
        obj.save()

    def UpdateDate(self, date: models.DateField()):
        self.Date = date
        self.save()