from django.urls import path

from . import views

urlpatterns = [
    path("operations/<str:operationId>", views.PerformOperation, name="PerformOperation"),
    path("operations/profile/<str:operationId>", views.PerformProfileOperation, name="PerformProfileOperation"),
    path("error/<int:errorCode>", views.DisplayError, name='Error'),
    path("login", views.Login, name='Login'),
    path("register", views.Register, name='Register'),
    path("main", views.Main, name="Main"), 
    path('pie-chart/', views.pie_chart, name='pie_chart'),
    path("main/profile", views.Profile, name="Profile"), 
    path("", views.Index, name="Index"),
]