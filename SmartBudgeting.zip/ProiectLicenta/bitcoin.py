from json import dump
from bitcoinlib.transactions import Transaction
import requests

block_hash = '00000000000000000000c85a0a2a0f1ac4049da5b8ea090be1570354eb359408'
block_url = 'https://blockchain.info/rawblock/' + block_hash

r = requests.get(block_url)
data = r.json()

with open("block_transactions.txt", "w") as file:
    file.write("Hash: " + block_hash + "\n")
    file.write("Transactions\n\n")

    for index, transaction in enumerate(data["tx"]):
        transaction_url = 'https://blockchain.info/rawtx/' + transaction['hash'] + '?format=hex'
        resp = requests.get(transaction_url)
        
        trans_obj = Transaction.import_raw(resp.content)
        # print(trans_obj.as_json())

        file.write('Index: ' + str(index) + '\n')
        file.write('Hash: ' + transaction['hash'] + '\n')
        file.write('Valid: ' + str(trans_obj.verify()) + '\n\n')