
import tensorflow as tf

from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.models import Sequential

import numpy as np

from pathlib import Path

data_dir = Path('bonuri/')

images = list(data_dir.glob('*.jpeg'))
print(images[0])

def getImageAsArray(path: str) -> np.array:
    image = tf.keras.utils.load_img(
        path,
        grayscale=False,
        color_mode="rgb",
        target_size=[1920,1080],
        interpolation="nearest",
        keep_aspect_ratio=False,
    )

    return np.array(image)

def prepareImageCSV():
    with open('dataset.csv', 'w') as file:
        file.write('Name,Path\n')

        for i in range(1,len(images)+1):
            string = 'bon'
            if i < 10:
                string += '00'
            elif i < 100:
                string += '0'
            file.write(string + str(i) + ',0.0\n')

import requests

receiptOcrEndpoint = 'https://ocr.asprise.com/api/v1/receipt' # Receipt OCR API endpoint
imageFile = "bonuri/bon005.jpeg" # // Modify it to use your own file
r = requests.post(receiptOcrEndpoint, data = { \
  'api_key': 'TEST',        # Use 'TEST' for testing purpose \
  'recognizer': 'auto',       # can be 'US', 'CA', 'JP', 'SG' or 'auto' \
  'ref_no': 'ocr_python_123', # optional caller provided ref code \
  }, \
  files = {"file": open(imageFile, "rb")})

import json

with open('res.json', 'w', encoding='utf-8') as file:
    file.write(r.text)
